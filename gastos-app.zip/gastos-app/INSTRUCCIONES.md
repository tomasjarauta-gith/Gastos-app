# 🚀 Instrucciones para publicar la app

Todo gratis. Seguí los pasos en orden.

---

## PASO 1 — Crear cuenta en GitHub
1. Entrá a **github.com**
2. Hacé click en **Sign up**
3. Usá tu cuenta de Google (Sign up with Google)
4. Elegí el plan **Free**

---

## PASO 2 — Subir los archivos a GitHub
1. Una vez dentro de GitHub, hacé click en **+** (arriba a la derecha) → **New repository**
2. Nombre: `gastos-app` (sin espacios)
3. Dejá en **Public**
4. Hacé click en **Create repository**
5. En la página que aparece, hacé click en **uploading an existing file**
6. **Arrastrá estos 3 archivos** al recuadro:
   - `index.html`
   - `vercel.json`
   - `public/manifest.json` (dentro de la carpeta public)
7. Hacé click en **Commit changes**

---

## PASO 3 — Crear proyecto en Firebase
1. Entrá a **console.firebase.google.com** con tu cuenta de Google
2. Hacé click en **Agregar proyecto** (o "Create a project")
3. Nombre: `gastos-compartidos` → Siguiente → Siguiente → Crear proyecto
4. Una vez creado, en el menú izquierdo hacé click en **Realtime Database**
5. Hacé click en **Crear base de datos**
6. Elegí la región más cercana (us-central1 está bien)
7. Seleccioná **Empezar en modo de prueba** → Habilitar

### Obtener credenciales:
1. En el menú izquierdo, hacé click en el engranaje ⚙ → **Configuración del proyecto**
2. Bajá hasta "Tus apps" → hacé click en el ícono **</>** (Web)
3. Nombre de la app: `gastos-web` → **Registrar app**
4. Vas a ver un bloque de código con `firebaseConfig`. **Copiá esos valores**, los necesitás para el paso siguiente.

---

## PASO 4 — Pegar las credenciales en el código
1. Volvé a GitHub → tu repositorio `gastos-app`
2. Hacé click en `index.html` → hacé click en el ícono del lápiz ✏️ (Edit)
3. Buscá esta sección (línea ~50):
   ```
   const firebaseConfig = {
     apiKey: "TU_API_KEY",
     authDomain: "TU_PROJECT.firebaseapp.com",
     ...
   ```
4. Reemplazá cada valor con los que copiaste de Firebase
5. Hacé click en **Commit changes**

---

## PASO 5 — Publicar en Vercel
1. Entrá a **vercel.com**
2. Hacé click en **Sign Up** → **Continue with GitHub**
3. Autorizá Vercel
4. Hacé click en **Add New Project** → **Import** en `gastos-app`
5. Dejá todo como está → hacé click en **Deploy**
6. En ~1 minuto te da un link tipo `gastos-app-xxx.vercel.app` 🎉

---

## PASO 6 — Instalar como app en el celu
### Android (Chrome):
1. Abrí el link en Chrome
2. Tocá los tres puntitos ⋮ → **Agregar a pantalla de inicio**

### iPhone (Safari):
1. Abrí el link en Safari
2. Tocá el ícono compartir ⬆ → **Agregar a pantalla de inicio**

---

## PASO 7 — Compartir con tu novia
Simplemente mandále el link de Vercel por WhatsApp.  
Ambos lo instalan en el celu y ven los gastos en tiempo real.

---

## 🔒 Nota de seguridad (opcional, recomendado)
Por ahora la base de datos está en "modo prueba" (cualquiera con el link puede leer/escribir).  
Para uso personal entre dos personas está bien así.  
Si querés agregar contraseña en el futuro, avisame y te explico cómo agregar autenticación.
